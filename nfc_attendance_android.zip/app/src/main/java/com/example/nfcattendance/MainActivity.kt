
package com.example.nfcattendance

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.MifareClassic
import android.nfc.tech.Ndef
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.BufferedWriter
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.*

// Simple data model
data class Attendance(
    val ts: Long,
    val direction: String, // IN / OUT
    val workerId: String,  // from NDEF text or UID
    val source: String     // NDEF / UID
)

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private lateinit var pendingIntent: PendingIntent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Log.e("NFC", "Device does not support NFC")
        }
        pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        setContent {
            App()
        }

        handleNfcIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, null, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleNfcIntent(intent)
    }

    private fun handleNfcIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        if (action == NfcAdapter.ACTION_TECH_DISCOVERED ||
            action == NfcAdapter.ACTION_TAG_DISCOVERED ||
            action == NfcAdapter.ACTION_NDEF_DISCOVERED) {

            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            tag?.let { t ->
                val uidHex = t.id?.joinToString("") { b -> "%02X".format(b) } ?: ""

                // Try read NDEF
                var workerId: String? = null
                var source = ""
                try {
                    val ndef = Ndef.get(t)
                    if (ndef != null) {
                        ndef.connect()
                        val msg: NdefMessage? = ndef.cachedNdefMessage ?: ndef.ndefMessage
                        msg?.records?.forEach { rec ->
                            val text = decodeNdefRecord(rec)
                            if (!text.isNullOrEmpty()) {
                                workerId = text
                            }
                        }
                        ndef.close()
                        if (!workerId.isNullOrEmpty()) source = "NDEF"
                    }
                } catch (e: Exception) {
                    Log.w("NFC", "NDEF read error: ${e.message}")
                }

                if (workerId.isNullOrEmpty()) {
                    // Fallback to UID
                    workerId = uidHex
                    source = "UID"
                }

                // Broadcast a local intent for Compose to consume
                val b = Bundle()
                b.putString("workerId", workerId)
                b.putString("source", source)
                val i = Intent("com.example.nfcattendance.CARD")
                i.putExtras(b)
                sendBroadcast(i)
            }
        }
    }

    private fun decodeNdefRecord(rec: NdefRecord): String? {
        return try {
            if (rec.tnf == NdefRecord.TNF_WELL_KNOWN && rec.type.contentEquals(NdefRecord.RTD_TEXT)) {
                val payload = rec.payload
                val langLen = payload[0].toInt() and 0x3F
                String(payload, 1 + langLen, payload.size - 1 - langLen, Charsets.UTF_8)
            } else {
                rec.payload?.let { String(it, Charsets.UTF_8) }
            }
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun App() {
    val context = LocalContext.current
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }

    var direction by remember { mutableStateOf("IN") }
    val logs = remember { mutableStateListOf<Attendance>() }
    var lastScanned by remember { mutableStateOf("—") }
    var nfcEnabled by remember { mutableStateOf(true) }

    // Broadcast receiver for NFC scans
    val receiver = remember {
        androidx.localbroadcastmanager.content.LocalBroadcastManager.getInstance(context)
    }

    LaunchedEffect(Unit) {
        // Check NFC enabled
        val adapter = NfcAdapter.getDefaultAdapter(context)
        nfcEnabled = adapter?.isEnabled == true
    }

    // Register system broadcast (using context.registerReceiver for simplicity)
    DisposableEffect(Unit) {
        val filter = android.content.IntentFilter("com.example.nfcattendance.CARD")
        val br = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
                val workerId = intent?.extras?.getString("workerId") ?: return
                val source = intent.extras?.getString("source") ?: ""
                val entry = Attendance(System.currentTimeMillis(), direction, workerId, source)
                logs.add(0, entry)
                lastScanned = "$workerId ($source)"
            }
        }
        context.registerReceiver(br, filter)
        onDispose { context.unregisterReceiver(br) }
    }

    // SAF export launcher
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { os ->
                writeCsv(os, logs)
            }
        }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("NFC 出入記錄", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    AssistChip(onClick = {
                        val adapter = NfcAdapter.getDefaultAdapter(context)
                        if (adapter?.isEnabled != true) {
                            context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
                        }
                    }, label = { Text(if (nfcEnabled) "NFC 開啟" else "NFC 關閉") })
                }

                Spacer(Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("方向：")
                    Spacer(Modifier.width(8.dp))
                    SegmentedButtons(direction) { direction = it }
                }

                Spacer(Modifier.height(8.dp))
                Text("最近掃描：$lastScanned")

                Spacer(Modifier.height(12.dp))
                Row {
                    Button(onClick = {
                        val fileName = "attendance_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.csv"
                        createDoc.launch(fileName)
                    }) {
                        Text("匯出 CSV")
                    }
                    Spacer(Modifier.width(12.dp))
                    Button(onClick = { logs.clear() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                        Text("清除記錄")
                    }
                }

                Spacer(Modifier.height(16.dp))

                Divider()
                Spacer(Modifier.height(8.dp))
                Text("記錄（最新在前）")

                LazyColumn(Modifier.fillMaxSize()) {
                    items(logs) { r ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(sdf.format(Date(r.ts)), modifier = Modifier.width(168.dp))
                            Text(r.direction, modifier = Modifier.width(56.dp), fontWeight = FontWeight.Bold)
                            Text(r.workerId, modifier = Modifier.weight(1f))
                            AssistChip(onClick = {}, label = { Text(r.source) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SegmentedButtons(selected: String, onChange: (String) -> Unit) {
    Row {
        FilterChip(selected = selected == "IN", onClick = { onChange("IN") }, label = { Text("進 / 上班") })
        Spacer(Modifier.width(8.dp))
        FilterChip(selected = selected == "OUT", onClick = { onChange("OUT") }, label = { Text("出 / 落班") })
    }
}

private fun writeCsv(os: OutputStream, logs: List<Attendance>) {
    val bw = BufferedWriter(OutputStreamWriter(os, Charsets.UTF_8))
    bw.write("timestamp,datetime,direction,worker_id,source")
    bw.newLine()
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    logs.asReversed().forEach { r ->
        val dt = sdf.format(Date(r.ts))
        bw.write("${r.ts},${dt},${r.direction},\"${r.workerId.replace("\"", "\"\"")}\",${r.source}")
        bw.newLine()
    }
    bw.flush()
}
